﻿Function Get-CustomRules
{
	<#
.SYNOPSIS
	  This command returns an ordered list of all Custom sync rules on an AAD Connect server.

.DESCRIPTION
	  This command returns a list of all custom sync rules on an AAD Connect server in an ordered list by precedence value.

.EXAMPLE
        Get-CustomRules	

.INPUTS
	None

.OUTPUTS
	List of all custom rules sorted in precedence order

.NOTES
	NAME:	Get-CustomRules.ps1
	AUTHOR:	Darryl Kegg
	DATE:	08 February, 2018
	EMAIL:	dkegg@microsoft.com

	VERSION HISTORY:
	1.0 08 February, 2018    Initial Version

THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
#>
	
	if (!(get-module ADsync)) { write-host -fore Red "This cmdlet should be run on an AAD Connect server. (ADSync module missing)";break }
	
	get-adsyncrule | where { $_.ImmutableTag.IsStandardTag -eq $false } | Select Precedence, Name, @{ n = "Connector"; e = { (Get-AdsyncConnector -Identifier $_.connector.tostring()).name } } | sort Precedence | ft -AutoSize
}


Function Get-DisabledRules ([switch]$All)
{
	<#
.SYNOPSIS
	  This command returns an ordered list of all disabled sync rules on an AAD Connect server.

.DESCRIPTION
	  This command returns a list of all disabled sync rules on an AAD Connect server in an ordered list by precedence value.

	  By default, only Out-Of-The-Box (OOTB) rules that are disabled are returned, however the -All switch can be used to return any disabled rules, in the event you have custom rules that are disabled.

.EXAMPLE
        Get-AllDisabledRules	

.PARAMETER All
	  Returns All disabled rules, not just Out-Of-The-Box (OOTB) rules that are disabled.

.INPUTS
	None

.OUTPUTS
	List of disabled rules sorted in precedence order

.NOTES
	NAME:	Get-AllDisabledRules.ps1
	AUTHOR:	Darryl Kegg
	DATE:	08 February, 2018
	EMAIL:	dkegg@microsoft.com

	VERSION HISTORY:
	1.0 08 February, 2018    Initial Version

THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
#>
	
	if (!(get-module ADsync)) { write-host -fore Red "This cmdlet should be run on an AAD Connect server. (ADSync module missing)"; break }
	
	If ($All)
	{
		get-adsyncrule | where { $_.disabled -eq $true } | Select Precedence, Name, @{ n = "Connector"; e = { (Get-AdsyncConnector -Identifier $_.connector.tostring()).name } } | sort Precedence | ft -AutoSize
	}
	Else
	{
		Write-Host -fore Yellow "Returning all DEFAULT rules that are disabled, to return ALL disabled rules use the -All switch"
		get-adsyncrule | where { $_.disabled -eq $true -and $_.ImmutableTag.IsStandardTag -eq $true } | Select Precedence, Name, @{ n = "Connector"; e = { (Get-AdsyncConnector -Identifier $_.connector.tostring()).name } } | sort Precedence | ft -AutoSize
	}
}

function Import-CustomRules
{
	
	<#
.SYNOPSIS
	  This command updates a TXT or PS1 file containing one or more exported sync rules with the connector ID of the target server.

.DESCRIPTION
	  This command takes a filename as an input, then prompts for a connector and updates the file by replacing the connector ID value.   The input file for this command should be one or more sync rules exported from the source AAD Connect server using the Export button in the SyncRulesEditor.  This script should be run on the destination AAD Connect server so that the correct connector can be selected for the replace.  The resulting file that is created is identical to the input but with .Updated appended.
	  
	  When exporting rules with the Export button, it is important to separate the files by connector, because the script only does a replace of a single connector within the file.   You should create one file for each AD connector, and if you have inbound and outbound customizations you will create 2 files per connector.   
	  
	  If you have only 1 AD connector, you will not be prompted for a connector, it will choose the AD connector automatically.

.PARAMETER FileName
	  File name of the export file from the source AAD Connect server.

.EXAMPLE
        Import-CustomRules -FileName ContosoInbound.ps1

	Prompts you to pick a connector ID from a list, then makes a copy of the file named ContosoInbound.Updated.Ps1 in the same folder as the source.

.INPUTS
	FileName

.OUTPUTS
	Copy of the input FileName with .Updated appended before the extension

.NOTES
	NAME:	Import-CustomRules.ps1
	AUTHOR:	Darryl Kegg
	DATE:	08 February, 2018
	EMAIL:	dkegg@microsoft.com

	VERSION HISTORY:
	1.0 08 February, 2018    Initial Version

THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
#>
	
	[CmdletBinding(SupportsShouldProcess = $True)]
	param
	(
		[Parameter(Mandatory = $True, HelpMessage = "File name of PS1 file")]
		[ValidateScript({
				If (!(Test-Path $_)) { Throw "FileName could not be found!" }
				Else { $True }
			})]
		[string]$FileName
	)
	
	if (!(get-module ADsync)) { write-host -fore Red "This cmdlet should be run on an AAD Connect server. (ADSync module missing)"; break }
	
	[array]$arrayConnectors = Get-ADSyncConnector | where { $_.name -notlike "* - AAD" } | select Name, Type, Identifier
	
	if ($arrayConnectors.count -eq 1)
	{
		Write-Host -fore Yellow "Only 1 non-Azure connector, using that connector ID"
		$connectorID = $arrayConnectors[0].Identifier
	}
	else
	{
		foreach ($number in (0 .. ($arrayConnectors.count - 1))) { Write-host "[$number] "$arrayConnectors[$number].name }
		Write-Host
		$Select = read-host "Please enter the number of the target connector"
		# write-host $arrayConnectors[$Select].name"will be used"
		$connectorID = $arrayConnectors[$Select].Identifier
	}
	
	if (!$connectorID)
	{
		Throw "Something is wrong - no connector ID was selected"
	}
	
	$file = Get-ChildItem $filename
	
	Get-Content $file.FullName | Where { $_ -notmatch "^Get-ADSyncRule" -and $_ -notmatch "^-identifier" } `
	| Foreach-Object { $_ -replace '-Connector.+', "-Connector '$connectorID' ``" } `
	| Set-Content "$($file.DirectoryName)\$($file.BaseName)-updated$($file.extension)"
}

Export-ModuleMember -Function Import-CustomRules
Export-ModuleMember -Function Get-DisabledRules
Export-ModuleMember -Function Get-CustomRules

